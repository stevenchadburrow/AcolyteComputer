// 2000 Hz is a one, 1000 Hz is a zero, make sure to do a full sine wave, probably an extra blanks

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

unsigned char HexToChar(char c)
{
	unsigned char value = 0;

	if (c >= '0' && c <= '9')
	{
		value = (char)(c - '0');
	}
	else if (c >= 'A' && c <= 'F')
	{
		value = (char)(c - 'A' + 10);
	}

	return value;
};

int main(const int argc, const char **argv)
{
	if (argc < 2)
	{
		printf("Arguments: <string>\n");
		printf("EX: \"Hello world!\"\n");
	
		return 0;
	}

	system("rec -q -t wav Short.wav synth 0.0005 sine 2000");
	system("sox -q -v 0.0001 Short.wav Quiet.wav");
	system("sox -q Quiet.wav Short.wav One.wav");
	system("rec -q -t wav Zero.wav synth 0.001 sine 1000");
	//system("rec -q -t wav Short.wav synth 0.001 sine 1000");
	//system("sox -q -v 0.0001 Short.wav Quiet.wav");
	//system("sox -q Quiet.wav Short.wav One.wav");
	//system("rec -q -t wav Zero.wav synth 0.002 sine 500");

	system("sox -q Quiet.wav Quiet.wav Quiet.wav Quiet.wav Next.wav ; mv Next.wav AudioPacket.wav");

	for (unsigned long loop=0; loop<strlen(argv[1]); loop++)
	{
		char key[32];

/*
		switch (argv[1][loop])
		{
			// only upper-case letters, numbers, period, return (/), and space
			case 'A': { sprintf(key, "1C"); break; }
			case 'B': { sprintf(key, "32"); break; }
			case 'C': { sprintf(key, "21"); break; }
			case 'D': { sprintf(key, "23"); break; }
			case 'E': { sprintf(key, "24"); break; }
			case 'F': { sprintf(key, "2B"); break; }
			case 'G': { sprintf(key, "34"); break; }
			case 'H': { sprintf(key, "33"); break; }
			case 'I': { sprintf(key, "43"); break; }
			case 'J': { sprintf(key, "3B"); break; }
			case 'K': { sprintf(key, "42"); break; }
			case 'L': { sprintf(key, "4B"); break; }
			case 'M': { sprintf(key, "3A"); break; }
			case 'N': { sprintf(key, "31"); break; }
			case 'O': { sprintf(key, "44"); break; }
			case 'P': { sprintf(key, "4D"); break; }
			case 'Q': { sprintf(key, "15"); break; }
			case 'R': { sprintf(key, "2D"); break; }
			case 'S': { sprintf(key, "1B"); break; }
			case 'T': { sprintf(key, "2C"); break; }
			case 'U': { sprintf(key, "3C"); break; }
			case 'V': { sprintf(key, "2A"); break; }
			case 'W': { sprintf(key, "1D"); break; }
			case 'X': { sprintf(key, "22"); break; }
			case 'Y': { sprintf(key, "35"); break; }
			case 'Z': { sprintf(key, "1A"); break; }
			case '0': { sprintf(key, "70"); break; }
			case '1': { sprintf(key, "69"); break; }
			case '2': { sprintf(key, "72"); break; }
			case '3': { sprintf(key, "7A"); break; }
			case '4': { sprintf(key, "6B"); break; }
			case '5': { sprintf(key, "73"); break; }
			case '6': { sprintf(key, "74"); break; }
			case '7': { sprintf(key, "6C"); break; }
			case '8': { sprintf(key, "75"); break; }
			case '9': { sprintf(key, "7D"); break; }
			case '.': { sprintf(key, "71"); break; }
			case ' ': { sprintf(key, "29"); break; }
			case '/': { sprintf(key, "5A"); break; }
			default: { sprintf(key, "00"); break; }
		}

		unsigned char byte = HexToChar(key[0]) * 16 + HexToChar(key[1]);
*/
		unsigned char byte = argv[1][loop];


		unsigned char bits[8];

		for (int i=7; i>=0; i--)
		{
			if (byte >= pow(2,i))
			{
				bits[i] = 1;
				byte -= pow(2,i);
			}
			else
			{
				bits[i] = 0;
			}
		}
	
		system("sox -q AudioPacket.wav Quiet.wav Quiet.wav Next.wav ; mv Next.wav AudioPacket.wav");
	
		for (int i=7; i>=0; i--)
		{
			if (bits[i] == 0) // zero
			{
				//printf("0");
				system("sox -q AudioPacket.wav Zero.wav Next.wav ; mv Next.wav AudioPacket.wav");
			}
			else // one
			{
				//printf("1");
				system("sox -q AudioPacket.wav One.wav Next.wav ; mv Next.wav AudioPacket.wav");
			}
		}
	
		// test packet
		//printf("\n");
		//system("play -q AudioPacket.wav");
	}

	system("play AudioPacket.wav");

	return 1;
}	



		 
