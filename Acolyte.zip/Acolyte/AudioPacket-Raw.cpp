// 2000 Hz is a one, 1000 Hz is a zero, make sure to do a full sine wave, probably an extra blanks

// this one uses a .raw file (just a .bin file basically) as input

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

unsigned char HexToChar(char c)
{
	unsigned char value = 0;

	if (c >= '0' && c <= '9')
	{
		value = (char)(c - '0');
	}
	else if (c >= 'A' && c <= 'F')
	{
		value = (char)(c - 'A' + 10);
	}

	return value;
};

int main(const int argc, const char **argv)
{
	if (argc < 2)
	{
		printf("Arguments: <file.raw>\n");
	
		return 0;
	}

	char command[1024];

	system("rec -q -t wav Short.wav synth 0.0005 sine 2000");
	system("sox -q -v 0.0001 Short.wav Quiet.wav");
	system("sox -q Quiet.wav Short.wav One.wav");
	system("rec -q -t wav Zero.wav synth 0.001 sine 1000");

	system("mkdir PremadeAudio");

	printf("Making premade audio files\n");
	
	for (int preloop=0; preloop<256; preloop++)
	{
		unsigned char byte = (unsigned char)preloop;
		unsigned char bits[8];

		for (int i=7; i>=0; i--)
		{
			if (byte >= pow(2,i))
			{
				bits[i] = 1;
				byte -= pow(2,i);
			}
			else
			{
				bits[i] = 0;
			}
		}
	
		system("sox -q Quiet.wav Quiet.wav Next.wav ; mv Next.wav AudioPacket-Raw.wav");
	
		for (int i=7; i>=0; i--)
		{
			if (bits[i] == 0) // zero
			{
				//printf("0");
				system("sox -q AudioPacket-Raw.wav Zero.wav Next.wav ; mv Next.wav AudioPacket-Raw.wav");
			}
			else // one
			{
				//printf("1");
				system("sox -q AudioPacket-Raw.wav One.wav Next.wav ; mv Next.wav AudioPacket-Raw.wav");
			}
		}

		for (int i=0; i<1024; i++) command[i] = 0;

		sprintf(command, "mv AudioPacket-Raw.wav PremadeAudio/Byte%03d.wav", preloop);

		system(command);
	}

	printf("Making audio packet file\n");

	system("sox -q Quiet.wav Quiet.wav Quiet.wav Quiet.wav Next.wav ; mv Next.wav AudioPacket-Raw.wav");

	FILE *input = NULL;
	input = fopen(argv[1], "rb");
	if (!input)
	{
		printf("File Error\n");
		return 0;
	}	

	unsigned char buffer = 0;
	int length = 0;

	unsigned long counter = 0;

	length = fscanf(input, "%c", &buffer);

	while (length > 0)
	{
		for (int i=0; i<1024; i++) command[i] = 0;

		sprintf(command, "sox -q AudioPacket-Raw.wav PremadeAudio/Byte%03d.wav Next.wav ; mv Next.wav AudioPacket-Raw.wav", (int)buffer);

		system(command);

		counter++;

		if (counter % 1024 == 0)
		{
			printf("%lu bytes encoded\n", counter);
		}

		length = fscanf(input, "%c", &buffer);
	}

	system("play AudioPacket-Raw.wav");

	return 1;
}	



		 
