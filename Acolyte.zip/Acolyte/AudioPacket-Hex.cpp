// 2000 Hz is a one, 1000 Hz is a zero, make sure to do a full sine wave, probably an extra blanks

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

unsigned char HexToChar(char c)
{
	unsigned char value = 0;

	if (c >= '0' && c <= '9')
	{
		value = (char)(c - '0');
	}
	else if (c >= 'A' && c <= 'F')
	{
		value = (char)(c - 'A' + 10);
	}

	return value;
};

int main(const int argc, const char **argv)
{
	if (argc < 2)
	{
		printf("Arguments: <hex codes>\n");
		printf("EX: FF 00 AA 55\n");
	
		return 0;
	}

	system("rec -q -t wav Short.wav synth 0.0005 sine 2000");
	system("sox -q -v 0.0001 Short.wav Quiet.wav");
	system("sox -q Quiet.wav Short.wav One.wav");
	system("rec -q -t wav Zero.wav synth 0.001 sine 1000");

	for (int loop=1; loop<argc; loop++)
	{
		unsigned char byte = HexToChar(argv[loop][0]) * 16 + HexToChar(argv[loop][1]);
		unsigned char bits[8];

		for (int i=7; i>=0; i--)
		{
			if (byte >= pow(2,i))
			{
				bits[i] = 1;
				byte -= pow(2,i);
			}
			else
			{
				bits[i] = 0;
			}
		}
	
		system("sox -q Quiet.wav Quiet.wav Next.wav ; mv Next.wav AudioPacket-Hex.wav");
	
		for (int i=7; i>=0; i--)
		{
			if (bits[i] == 0) // zero
			{
				//printf("0");
				system("sox -q AudioPacket-Hex.wav Zero.wav Next.wav ; mv Next.wav AudioPacket-Hex.wav");
			}
			else // one
			{
				//printf("1");
				system("sox -q AudioPacket-Hex.wav One.wav Next.wav ; mv Next.wav AudioPacket-Hex.wav");
			}
		}
	
		// test packet
		//printf("\n");
		system("play -q AudioPacket-Hex.wav");
	}

	return 1;
}	



		 
