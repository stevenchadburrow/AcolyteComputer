#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

unsigned char BinaryToChar(const char *b)
{
	unsigned char value = 0;

	for (int i=0; i<8; i++)
	{
		if (b[i] == '1')
		{
			value += pow(2,7-i);
		}
		else if (b[i] == '0')
		{
			value += 0;
		}
		else
		{
			printf("Unrecognized Binary Value!\n");
			
			return 0;
		}
	}

	return value;
};

int main()
{
	FILE *output = NULL;

	output = fopen("VideoROM.bin", "wb");
	if (!output)
	{
		printf("Error writing file!\n");
		return 0;
	}

	for (int i=0; i<393216; i++) // fluff the rest of the 512K - 128K memory (for sst39sf040)
	{
		fprintf(output, "%c", 92);
	}

	for (int i=0; i<480; i++) // 480 rows visible
	{
		for (int j=0; j<80; j++) // 640/8=80 columns visible
		{
			fprintf(output, "%c", BinaryToChar("01111111"));
		}

		for (int j=0; j<2; j++) // 16/8=2 columns front porch
		{
			fprintf(output, "%c", BinaryToChar("10111110"));
		}

		for (int j=0; j<12; j++) // 96/8=12 columns h-sync
		{
			fprintf(output, "%c", BinaryToChar("10111100"));
		}
	
		for (int j=0; j<5; j++) // 40/8=5 columns back porch (one missing)
		{
			fprintf(output, "%c", BinaryToChar("10111110"));
		}

		// 8/8=1 column back porch (with h-reset, last one goes to v-blank)
		if (i == 479) fprintf(output, "%c", BinaryToChar("10110011"));
		else fprintf(output, "%c", BinaryToChar("01111011"));
		
		for (int j=0; j<28; j++) // 224/8=28 columns null
		{
			fprintf(output, "%c", BinaryToChar("10111110"));
		}
	}

	for (int i=0; i<10; i++) // 10 rows front porch
	{
		for (int j=0; j<80; j++) // 640/8=80 columns visible
		{
			fprintf(output, "%c", BinaryToChar("10110111"));
		}

		for (int j=0; j<2; j++) // 16/8=2 columns front porch
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}

		for (int j=0; j<12; j++) // 96/8=12 columns h-sync
		{
			fprintf(output, "%c", BinaryToChar("10110100"));
		}
	
		for (int j=0; j<5; j++) // 40/8=5 columns back porch (one missing)
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}

		// 8/8=1 column back porch (with h-reset)
		fprintf(output, "%c", BinaryToChar("10110011"));
		
		for (int j=0; j<28; j++) // 224/8=28 columns null
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}
	}

	for (int i=0; i<2; i++) // 2 rows v-sync
	{
		for (int j=0; j<80; j++) // 640/8=80 columns visible
		{
			fprintf(output, "%c", BinaryToChar("10100111"));
		}

		for (int j=0; j<2; j++) // 16/8=2 columns front porch
		{
			fprintf(output, "%c", BinaryToChar("10100110"));
		}

		for (int j=0; j<12; j++) // 96/8=12 columns h-sync
		{
			fprintf(output, "%c", BinaryToChar("10100100"));
		}
	
		for (int j=0; j<5; j++) // 40/8=5 columns back porch (one missing)
		{
			fprintf(output, "%c", BinaryToChar("10100110"));
		}

		// 8/8=1 column back porch (with h-reset)
		fprintf(output, "%c", BinaryToChar("10100011"));
		
		for (int j=0; j<28; j++) // 224/8=28 columns null
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}
	}

	for (int i=0; i<33; i++) // 33 rows back porch
	{
		for (int j=0; j<80; j++) // 640/8=80 columns visible
		{
			fprintf(output, "%c", BinaryToChar("10110111"));
		}

		for (int j=0; j<2; j++) // 16/8=2 columns front porch
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}

		for (int j=0; j<12; j++) // 96/8=12 columns h-sync
		{
			fprintf(output, "%c", BinaryToChar("10110100"));
		}
	
		for (int j=0; j<5; j++) // 40/8=5 columns back porch (one missing)
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}

		// 8/8=1 column back porch (with h-reset and v-reset if last row)
		if (i == 32) fprintf(output, "%c", BinaryToChar("01011011"));
		else fprintf(output, "%c", BinaryToChar("10110011"));
		
		for (int j=0; j<28; j++) // 224/8=28 columns null
		{
			fprintf(output, "%c", BinaryToChar("10110110"));
		}
	}

	for (int i=0; i<63872; i++) // fluff the rest of the 128K memory
	{
		fprintf(output, "%c", 92);
	}

	fclose(output);

	return 1;
}
