// Converts a 1024x8 (128 characters) .bmp file into raw hex data

#include <stdio.h>
#include <stdlib.h>

int main(const int argc, const char **argv)
{
	if (argc < 3)
	{
		printf("Arguments: <input.bmp> <output-mono.hex> <output-four.hex>\n");

		return 0;
	}

	FILE *input, *output1, *output2;

	input = fopen(argv[1], "rb");
	if (!input)
	{
		printf("Error reading .bmp\n");

		return 0;
	}

	output1 = fopen(argv[2], "wt");
	if (!output1)
	{
		printf("Error writing #1 .hex\n");

		return 0;
	}

	output2 = fopen(argv[3], "wt");
	if (!output2)
	{
		printf("Error writing #2 .hex\n");

		return 0;
	}

	unsigned char buffer;

	unsigned char mono, high, low;

	unsigned char red, green, blue;

	unsigned char full_mono[2048], full_high[2048], full_low[2048];

	for (int i=0; i<2048; i++)
	{
		full_mono[i] = 0;
		full_high[i] = 0;
		full_low[i] = 0;
	}

	unsigned int total = 0;

	for (int i=0; i<54; i++) fscanf(input, "%c", &buffer); // header info

	for (int i=0; i<8; i++)
	{
		for (int j=0; j<1024/4; j++)
		{
			if (j % 2 == 0) mono = 0;
			low = 0;
			high = 0;

			fscanf(input, "%c%c%c", &blue, &green, &red); // for some reason, it always reads blue, then green, then red

			if (red < 128 && green < 128 && blue < 128) mono += 0;
			else
			{
				if (j % 2 == 0) mono += 128;
				else mono += 8;
			}

			if (red < 128 && green < 128 && blue < 128) high += 0;
			else if (red >= 128 && green < 128 && blue < 128) high += 4;
			else if (red < 128 && green >= 128 && blue >= 128) high += 8;
			else if (red >= 128 && green >= 128 && blue >= 128) high += 12;
			else
			{
				printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
				
				fclose(input);
				fclose(output1);
				fclose(output2);

				return 0;
			}

			fscanf(input, "%c%c%c", &blue, &green, &red);

			if (red < 128 && green < 128 && blue < 128) mono += 0;
			else
			{
				if (j % 2 == 0) mono += 64;
				else mono += 4;
			}

			if (red < 128 && green < 128 && blue < 128) high += 0;
			else if (red >= 128 && green < 128 && blue < 128) high += 1;
			else if (red < 128 && green >= 128 && blue >= 128) high += 2;
			else if (red >= 128 && green >= 128 && blue >= 128) high += 3;
			else
			{
				printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
				
				fclose(input);
				fclose(output1);
				fclose(output2);

				return 0;
			}

			fscanf(input, "%c%c%c", &blue, &green, &red);

			if (red < 128 && green < 128 && blue < 128) mono += 0;
			else
			{
				if (j % 2 == 0) mono += 32;
				else mono += 2; 
			}

			if (red < 128 && green < 128 && blue < 128) low += 0;
			else if (red >= 128 && green < 128 && blue < 128) low += 4;
			else if (red < 128 && green >= 128 && blue >= 128) low += 8;
			else if (red >= 128 && green >= 128 && blue >= 128) low += 12;
			else
			{
				printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
				
				fclose(input);
				fclose(output1);
				fclose(output2);

				return 0;
			}

			fscanf(input, "%c%c%c", &blue, &green, &red);

			if (red < 128 && green < 128 && blue < 128) mono += 0;
			else
			{
				if (j % 2 == 0) mono += 16;
				else mono += 1;
			}

			if (red < 128 && green < 128 && blue < 128) low += 0;
			else if (red >= 128 && green < 128 && blue < 128) low += 1;
			else if (red < 128 && green >= 128 && blue >= 128) low += 2;
			else if (red >= 128 && green >= 128 && blue >= 128) low += 3;
			else
			{
				printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
				
				fclose(input);
				fclose(output1);
				fclose(output2);

				return 0;
			}

			if (j % 2 == 1)
			{
				unsigned char temp = mono / 16;
				
				if (temp < 10) temp = (char)(temp + '0');
				else temp = (char)((temp-10) + 'A');

				full_mono[total-1] = temp;

				temp = mono % 16;

				if (temp < 10) temp = (char)(temp + '0');
				else temp = (char)((temp-10) + 'A');

				full_mono[total] = temp;
			}

			if (low < 10) low = (char)(low + '0');
			else low = (char)((low-10) + 'A');

			if (high < 10) high = (char)(high + '0');
			else high = (char)((high-10) + 'A');

			full_high[total] = high;
			full_low[total] = low;

			total++;
		}
	}

	for (int i=0; i<128; i++) // inverting the y-values, because... we need to?
	{
		for (int k=7; k>=0; k--)
		{
			fprintf(output1, "$%c%c ", full_mono[(k*1024/4)+i*2], full_mono[(k*1024/4)+i*2+1]);
		}

		fprintf(output1, "\n");
	}

	fprintf(output1, "\n\n");

	for (int i=0; i<128; i++) // inverting the y-values, because... we need to?
	{
		fprintf(output1, "\t.BYTE ");

		for (int k=7; k>=4; k--)
		{
			fprintf(output1, "$%c%c,", full_mono[(k*1024/4)+i*2], full_mono[(k*1024/4)+i*2+1]);
		}

		for (int k=3; k>=0; k--)
		{
			if (k == 0) fprintf(output1, "$%c%c", full_mono[(k*1024/4)+i*2], full_mono[(k*1024/4)+i*2+1]);
			else fprintf(output1, "$%c%c,", full_mono[(k*1024/4)+i*2], full_mono[(k*1024/4)+i*2+1]);
		}

		fprintf(output1, "\n");
	}

	fprintf(output1, "\n\n");

	for (int i=0; i<128; i++) // inverting the y-values, because... we need to?
	{
		fprintf(output1, "\t.BYTE ");

		for (int k=7; k>=4; k--)
		{
			fprintf(output1, "$00,");
		}

		for (int k=3; k>=0; k--)
		{
			if (k == 0) fprintf(output1, "$00");
			else fprintf(output1, "$00,");
		}

		fprintf(output1, "\n");
	}

	for (int i=0; i<128; i++) // inverting the y-values, because... we need to?
	{
		for (int k=7; k>=0; k--)
		{
			for (int j=0; j<2; j++)
			{
				fprintf(output2, "$%c%c ", full_high[(k*1024/4)+i*2+j], full_low[(k*1024/4)+i*2+j]);
			}
		}

		fprintf(output2, "\n");
	}

	fprintf(output2, "\n\n");

	for (int i=0; i<128; i++) // inverting the y-values, because... we need to?
	{
		fprintf(output2, "\t.BYTE ");

		for (int k=7; k>=4; k--)
		{
			for (int j=0; j<2; j++)
			{
				if (k == 4 && j == 1) fprintf(output2, "$%c%c", full_high[(k*1024/4)+i*2+j], full_low[(k*1024/4)+i*2+j]);
				else fprintf(output2, "$%c%c,", full_high[(k*1024/4)+i*2+j], full_low[(k*1024/4)+i*2+j]);
			}
		}

		fprintf(output2, "\n");

		fprintf(output2, "\t.BYTE ");

		for (int k=3; k>=0; k--)
		{
			for (int j=0; j<2; j++)
			{
				if (k == 0 && j == 1) fprintf(output2, "$%c%c", full_high[(k*1024/4)+i*2+j], full_low[(k*1024/4)+i*2+j]);
				else fprintf(output2, "$%c%c,", full_high[(k*1024/4)+i*2+j], full_low[(k*1024/4)+i*2+j]);
			}
		}

		fprintf(output2, "\n");
	}

	fclose(input);
	fclose(output1);
	fclose(output2);
	
	return 1;
}
