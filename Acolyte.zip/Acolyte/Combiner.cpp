#include <stdio.h>
#include <stdlib.h>

int main(const int argc, const char **argv)
{
	if (argc < 6)
	{
		printf("Combines four 32K .bin files into a single 128K .bin file\n");
		printf("Arguments: <input1.bin> <input2.bin> <input3.bin> <input4.bin> <output.bin>\n");
	
		return 0;
	}

	FILE *input[4];

	input[0] = NULL;
	input[1] = NULL;
	input[2] = NULL;
	input[3] = NULL;

	for (int i=0; i<4; i++)
	{
		input[i] = fopen(argv[i+1], "rb");
		if (!input[i])
		{
			printf("Input Error\n");
		
			return 0;
		}
	}

	FILE *output = NULL;

	output = fopen(argv[5], "wb");
	if (!output)
	{
		printf("Output Error\n");

		return 0;
	}

	unsigned char buffer;

	for (int i=0; i<4; i++)
	{
		for (unsigned int j=0; j<32768; j++)
		{
			fscanf(input[i], "%c", &buffer);
			fprintf(output, "%c", buffer);
		}
	}

	for (int i=0; i<4; i++)
	{
		fclose(input[i]);
	}

	fclose(output);

	return 1;
}
