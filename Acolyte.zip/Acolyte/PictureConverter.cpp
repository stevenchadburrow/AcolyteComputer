// Converts a 640x240 mono, 320x240 4-color, or 160x240 16-color .bmp file into raw hex data

#include <stdio.h>
#include <stdlib.h>

unsigned char HexToChar(char c)
{
	unsigned char value = 0;

	if (c >= '0' && c <= '9')
	{
		value = (char)(c - '0');
	}
	else if (c >= 'A' && c <= 'F')
	{
		value = (char)(c - 'A' + 10);
	}

	return value;
};


int main(const int argc, const char **argv)
{
	if (argc < 4)
	{
		printf("Converts a picture into Hex code.\n");
		printf("Arguments: <input.bmp> <output.hex> <colors>\n");
		printf("<colors> tells what type of picture it is.\n");
		printf("Options would be:\n");
		printf("2 -> requires 640x240 pixels\n");
		printf("4 -> requires 320x240 pixels\n");
		printf("16 -> requires 160x240 pixels\n");
		printf("Example:\n");
		printf("./PictureConverter.o GouldianFinch-Mono.bmp GouldianFinch-Mono.hex 2\n");

		return 0;
	}

	FILE *input, *output, *raw;

	input = fopen(argv[1], "rb");
	if (!input)
	{
		printf("Error reading .bmp\n");

		return 0;
	}

	output = fopen(argv[2], "wt");
	if (!output)
	{
		printf("Error writing .hex\n");

		return 0;
	}

	raw = fopen("PictureConverter.raw", "wb");
	if (!raw)
	{
		printf("Error in .raw\n");
	
		return 0;
	}

	unsigned char buffer;

	unsigned char high, low;

	unsigned char red, green, blue;

	unsigned char full_high[32000], full_low[32000];

	for (int i=0; i<32000; i++)
	{
		full_high[i] = 0;
		full_low[i] = 0;
	}

	unsigned int total = 0;

	for (int i=0; i<54; i++) fscanf(input, "%c", &buffer); // header information

	if (atoi(argv[3]) == 2) // monochrome
	{
		for (int i=0; i<240; i++)
		{
			for (int j=0; j<640/8; j++)
			{
				low = 0;
				high = 0;

				fscanf(input, "%c%c%c", &blue, &green, &red); // for some reason, it always reads blue, then green, then red

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else high += 8;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else high += 4;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else high += 2;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else high += 1;

				fscanf(input, "%c%c%c", &blue, &green, &red); // for some reason, it always reads blue, then green, then red

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else low += 8;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else low += 4;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else low += 2;

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else low += 1;

				if (low < 10) low = (char)(low + '0');
				else low = (char)((low-10) + 'A');

				if (high < 10) high = (char)(high + '0');
				else high = (char)((high-10) + 'A');

				full_high[total] = high;
				full_low[total] = low;

				total++;
			}

			for (int j=640/8; j<1024/8; j++)
			{
				full_high[total] = '0';
				full_low[total] = '0';

				total++;
			}
		}

		for (int i=240-1; i>=0; i--) // inverting the y-values, because... we need to?
		{
			for (int j=0; j<1024/8; j+=8)
			{
				fprintf(output,"\t.BYTE ");

				for (int k=0; k<8; k++)
				{
					if (k == 7) fprintf(output, "$%c%c", full_high[(i*1024/8)+j+k], full_low[(i*1024/8)+j+k]);
					else fprintf(output, "$%c%c,", full_high[(i*1024/8)+j+k], full_low[(i*1024/8)+j+k]);

					fprintf(raw, "%c", HexToChar(full_high[(i*1024/8)+j+k])*16+HexToChar(full_low[(i*1024/8)+j+k]));
				}

				fprintf(output, "\n");
			}
		}
	}
	else if (atoi(argv[3]) == 4) // four colors
	{
		for (int i=0; i<240; i++)
		{
			for (int j=0; j<320/4; j++)
			{
				low = 0;
				high = 0;

				fscanf(input, "%c%c%c", &blue, &green, &red); // for some reason, it always reads blue, then green, then red

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else if (red < 128 && green >= 128 && blue >= 128) high += 4;
				else if (red >= 128 && green < 128 && blue < 128) high += 8;
				else if (red >= 128 && green >= 128 && blue >= 128) high += 12;
				else
				{
					printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
					fclose(input);
					fclose(output);

					return 0;
				}

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) high += 0;
				else if (red < 128 && green >= 128 && blue >= 128) high += 1;
				else if (red >= 128 && green < 128 && blue < 128) high += 2;
				else if (red >= 128 && green >= 128 && blue >= 128) high += 3;
				else
				{
					printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
					fclose(input);
					fclose(output);

					return 0;
				}

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else if (red < 128 && green >= 128 && blue >= 128) low += 4;
				else if (red >= 128 && green < 128 && blue < 128) low += 8;
				else if (red >= 128 && green >= 128 && blue >= 128) low += 12;
				else
				{
					printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
					fclose(input);
					fclose(output);

					return 0;
				}

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 128 && green < 128 && blue < 128) low += 0;
				else if (red < 128 && green >= 128 && blue >= 128) low += 1;
				else if (red >= 128 && green < 128 && blue < 128) low += 2;
				else if (red >= 128 && green >= 128 && blue >= 128) low += 3;
				else
				{
					printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
					fclose(input);
					fclose(output);

					return 0;
				}

				if (low < 10) low = (char)(low + '0');
				else low = (char)((low-10) + 'A');

				if (high < 10) high = (char)(high + '0');
				else high = (char)((high-10) + 'A');

				full_high[total] = high;
				full_low[total] = low;

				total++;
			}

			for (int j=320/4; j<512/4; j++)
			{
				full_high[total] = '0';
				full_low[total] = '0';

				total++;
			}
		}

		for (int i=240-1; i>=0; i--) // inverting the y-values, because... we need to?
		{
			for (int j=0; j<512/4; j+=8)
			{
				fprintf(output,"\t.BYTE ");

				for (int k=0; k<8; k++)
				{
					if (k == 7) fprintf(output, "$%c%c", full_high[(i*512/4)+j+k], full_low[(i*512/4)+j+k]);
					else fprintf(output, "$%c%c,", full_high[(i*512/4)+j+k], full_low[(i*512/4)+j+k]);

					fprintf(raw, "%c", HexToChar(full_high[(i*1024/8)+j+k])*16+HexToChar(full_low[(i*1024/8)+j+k]));
				}

				fprintf(output, "\n");
			}
		}
	}
	else if (atoi(argv[3]) == 16) // sixteen colors
	{
		for (int i=0; i<240; i++)
		{
			for (int j=0; j<160/2; j++)
			{
				low = 0;
				high = 0;

				fscanf(input, "%c%c%c", &blue, &green, &red); // for some reason, it always reads blue, then green, then red

				if (red < 32 && green < 32 && blue < 32) high = 0; // black
				else if (red >= 32 && green < 32 && blue < 32)
				{
					if (red < 192) high = 8; // dark red
					else high = 9; // bright red
				}
				else if (red < 32 && green >= 32 && blue < 32)
				{
					if (green < 192) high = 4; // dark green
					else high = 5; // bright green
				}
				else if (red < 32 && green < 32 && blue >= 32)
				{
					if (blue < 192) high = 2; // dark blue
					else high = 3; // bright blue
				}
				else if (red >= 32 && green >= 32 && blue < 32)
				{
					if (red < 192 && green < 192) high = 12; // dark yellow
					else if (red >= 192 && green >= 192) high = 13; // bright yellow
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red >= 32 && green < 32 && blue > 32)
				{
					if (red < 192 && blue < 192) high = 10; // dark magenta
					else if (red >= 192 && blue >= 192) high = 11; // bright magenta
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red < 32 && green >= 32 && blue >= 32)
				{
					if (green < 192 && blue < 192) high = 6; // dark cyan
					else if (green >= 192 && blue >= 192) high = 7; // bright cyan
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red < 96 && green < 96 && blue < 96) high = 14; // dark grey
				else if (red < 224 && green < 224 && blue < 224) high = 1; // light grey
				else high = 15; // white

				fscanf(input, "%c%c%c", &blue, &green, &red);

				if (red < 32 && green < 32 && blue < 32) low = 0; // black
				else if (red >= 32 && green < 32 && blue < 32)
				{
					if (red < 192) low = 8; // dark red
					else low = 9; // bright red
				}
				else if (red < 32 && green >= 32 && blue < 32)
				{
					if (green < 192) low = 4; // dark green
					else low = 5; // bright green
				}
				else if (red < 32 && green < 32 && blue >= 32)
				{
					if (blue < 192) low = 2; // dark blue
					else low = 3; // bright blue
				}
				else if (red >= 32 && green >= 32 && blue < 32)
				{
					if (red < 192 && green < 192) low = 12; // dark yellow
					else if (red >= 192 && green >= 192) low = 13; // bright yellow
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red >= 32 && green < 32 && blue > 32)
				{
					if (red < 192 && blue < 192) low = 10; // dark magenta
					else if (red >= 192 && blue >= 192) low = 11; // bright magenta
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red < 32 && green >= 32 && blue >= 32)
				{
					if (green < 192 && blue < 192) low = 6; // dark cyan
					else if (green >= 192 && blue >= 192) low = 7; // bright cyan
					else
					{
						printf("Unsupported Color RGB(%d %d %d) @ (%d,%d)!  Only: Black, Red, Cyan, and White\n", red, green, blue, j, i);
					
						fclose(input);
						fclose(output);

						return 0;
					}
				}
				else if (red < 96 && green < 96 && blue < 96) low = 14; // dark grey
				else if (red < 224 && green < 224 && blue < 224) low = 1; // light grey
				else low = 15; // white
				

				if (low < 10) low = (char)(low + '0');
				else low = (char)((low-10) + 'A');

				if (high < 10) high = (char)(high + '0');
				else high = (char)((high-10) + 'A');

				full_high[total] = high;
				full_low[total] = low;

				total++;
			}

			for (int j=160/2; j<256/2; j++)
			{
				full_high[total] = '0';
				full_low[total] = '0';

				total++;
			}
		}

		for (int i=240-1; i>=0; i--) // inverting the y-values, because... we need to?
		{
			for (int j=0; j<256/2; j+=8)
			{
				fprintf(output,"\t.BYTE ");

				for (int k=0; k<8; k++)
				{
					if (k == 7) fprintf(output, "$%c%c", full_high[(i*256/2)+j+k], full_low[(i*256/2)+j+k]);
					else fprintf(output, "$%c%c,", full_high[(i*256/2)+j+k], full_low[(i*256/2)+j+k]);

					fprintf(raw, "%c", HexToChar(full_high[(i*1024/8)+j+k])*16+HexToChar(full_low[(i*1024/8)+j+k]));
				}

				fprintf(output, "\n");
			}
		}
	}
	

	fclose(input);

	fclose(output);

	fclose(raw);
	
	return 1;
}
